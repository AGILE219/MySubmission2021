package com.oocode.assignment2021;

public class Charger {
    public final int speed;
    public final String type;

    public Charger(int speed, String type) {
        this.speed = speed;
        this.type = type;
    }
}
